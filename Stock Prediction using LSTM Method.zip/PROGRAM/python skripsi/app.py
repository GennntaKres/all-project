from flask import Flask, render_template, request, url_for
from matplotlib.pyplot import legend
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from tensorflow.keras.models import load_model
import numpy as np

app = Flask(__name__)


@app.route("/")
def home():
    return render_template("home.html")

@app.route("/Menu")
def menu():
    return render_template("menu.html")

@app.route("/ADRO")
def adro():
    return render_template("adro.html")

@app.route("/ADRO5")
def adro5():
    return render_template("adro5.html")

@app.route("/ADRO7")
def adro7():
    return render_template("adro7.html")

@app.route("/ANTM")
def antm():
    return render_template("antm.html")

@app.route("/BBCA")
def bbca():
    return render_template("bbca.html")

@app.route("/BBNI")
def bbni():
    return render_template("bbni.html")

@app.route("/BBRI")
def bbri():
    return render_template("bbri.html")

@app.route("/BBTN")
def bbtn():
    return render_template("bbtn.html")

@app.route("/BMRI")
def bmri():
    return render_template("bmri.html")

@app.route("/EXCL")
def excl():
    return render_template("excl.html")

@app.route("/GGRM")
def ggrm():
    return render_template("ggrm.html")

@app.route("/HMSP")
def hmsp():
    return render_template("hmsp.html")

@app.route("/ICBP")
def icbp():
    return render_template("icbp.html")

@app.route("/INDF")
def indf():
    return render_template("indf.html")

@app.route("/JPFA")
def jpfa():
    return render_template("jpfa.html")

@app.route("/MDKA")
def mdka():
    return render_template("mdka.html")

@app.route("/TLKM")
def tlkm():
    return render_template("tlkm.html")

labels = ['D-3','D-2', 'D-1', 'D']
labels5 = ['D-5','D-4','D-3','D-2', 'D-1', 'D']
labels7 = ['D-7','D-6','D-5','D-4','D-3','D-2', 'D-1', 'D']

def inputpredict(model,arr):
    npinputan = np.asarray(arr)
    npinputan = npinputan.reshape(3,1)

    sc = MinMaxScaler(feature_range=(0,1))
    npinputan_val = sc.fit_transform(npinputan)

    input = npinputan_val.reshape(npinputan_val.shape[0], 1, npinputan_val.shape[1])
    pred = model.predict(input)
    pred_inverse = sc.inverse_transform(pred)
    pred_inverse = pred_inverse.round()

    return pred_inverse

def inputpredict5(model,arr):
    npinputan = np.asarray(arr)
    npinputan = npinputan.reshape(5,1)

    sc = MinMaxScaler(feature_range=(0,1))
    npinputan_val = sc.fit_transform(npinputan)

    input = npinputan_val.reshape(npinputan_val.shape[0], 1, npinputan_val.shape[1])
    pred = model.predict(input)
    pred_inverse = sc.inverse_transform(pred)
    pred_inverse = pred_inverse.round()

    return pred_inverse

def inputpredict7(model,arr):
    npinputan = np.asarray(arr)
    npinputan = npinputan.reshape(7,1)

    sc = MinMaxScaler(feature_range=(0,1))
    npinputan_val = sc.fit_transform(npinputan)

    input = npinputan_val.reshape(npinputan_val.shape[0], 1, npinputan_val.shape[1])
    pred = model.predict(input)
    pred_inverse = sc.inverse_transform(pred)
    pred_inverse = pred_inverse.round()

    return pred_inverse

@app.route("/ADRO", methods=["POST", "GET"])
def predictAdro():
    if request.method == "GET":
        return render_template("adro.html")
    
    else:
        modelAdro = load_model(r"static\models\ADRO.h5")
        inputan = []

        inputan.append(float(request.form["adro_3"]))
        inputan.append(float(request.form["adro_2"]))
        inputan.append(float(request.form["adro_1"]))

        predict = inputpredict(modelAdro,inputan)
        inputan.append(predict[2])
        if (inputan[2] == predict[2]):
            line_labels = labels
            line_values = inputan
            return render_template("adro.html",result= predict[2],profit= "+0.0%", legend= "Prediction Chart" , max=5000, labels=line_labels, values=line_values)
        if (inputan[2] > predict[2]):
            percentage = ((inputan[2]-predict[2])/predict[2])*100
            line_labels = labels
            line_values = inputan
            return render_template("adro.html",result= predict[2],profit= "-"+str(round(float(percentage),2))+"%", legend= "Prediction Chart" , max=5000, labels=line_labels, values=line_values)
        if (inputan[2] < predict[2]):
            percentage = ((inputan[2]-predict[2])/predict[2])*100
            line_labels = labels
            line_values = inputan
            return render_template("adro.html",result= predict[2],profit= "+"+str(round(float(percentage)*-1,2))+"%", legend= "Prediction Chart" , max=5000, labels=line_labels, values=line_values)
        
@app.route("/ADRO5", methods=["POST", "GET"])
def predictAdro5():
    if request.method == "GET":
        return render_template("adro5.html")
    
    else:
        modelAdro = load_model(r"static\models\ADRO.h5")
        inputan = []

        inputan.append(float(request.form["adro_5"]))
        inputan.append(float(request.form["adro_4"]))
        inputan.append(float(request.form["adro_3"]))
        inputan.append(float(request.form["adro_2"]))
        inputan.append(float(request.form["adro_1"]))

        predict = inputpredict5(modelAdro,inputan)
        inputan.append(predict[4])
        if (inputan[4] == predict[4]):
            line_labels = labels5
            line_values = inputan
            return render_template("adro5.html",result= predict[4],profit= "+0.0%", legend= "Prediction Chart" , max=5000, labels=line_labels, values=line_values)
        if (inputan[4] > predict[4]):
            percentage = ((inputan[4]-predict[4])/predict[4])*100
            line_labels = labels5
            line_values = inputan
            return render_template("adro5.html",result= predict[4],profit= "-"+str(round(float(percentage),2))+"%", legend= "Prediction Chart" , max=5000, labels=line_labels, values=line_values)
        if (inputan[4] < predict[4]):
            percentage = ((inputan[4]-predict[4])/predict[4])*100
            line_labels = labels5
            line_values = inputan
            return render_template("adro5.html",result= predict[4],profit= "+"+str(round(float(percentage)*-1,2))+"%", legend= "Prediction Chart" , max=5000, labels=line_labels, values=line_values)    

@app.route("/ADRO7", methods=["POST", "GET"])
def predictAdro7():
    if request.method == "GET":
        return render_template("adro7.html")
    
    else:
        modelAdro = load_model(r"static\models\ADRO.h5")
        inputan = []

        inputan.append(float(request.form["adro_7"]))
        inputan.append(float(request.form["adro_6"]))
        inputan.append(float(request.form["adro_5"]))
        inputan.append(float(request.form["adro_4"]))
        inputan.append(float(request.form["adro_3"]))
        inputan.append(float(request.form["adro_2"]))
        inputan.append(float(request.form["adro_1"]))

        predict = inputpredict7(modelAdro,inputan)
        inputan.append(predict[6])
        if (inputan[6] == predict[6]):
            line_labels = labels7
            line_values = inputan
            return render_template("adro7.html",result= predict[6],profit= "+0.0%", legend= "Prediction Chart" , max=5000, labels=line_labels, values=line_values)
        if (inputan[6] > predict[6]):
            percentage = ((inputan[6]-predict[6])/predict[6])*100
            line_labels = labels7
            line_values = inputan
            return render_template("adro7.html",result= predict[6],profit= "-"+str(round(float(percentage),2))+"%", legend= "Prediction Chart" , max=5000, labels=line_labels, values=line_values)
        if (inputan[6] < predict[6]):
            percentage = ((inputan[6]-predict[6])/predict[6])*100
            line_labels = labels7
            line_values = inputan
            return render_template("adro7.html",result= predict[6],profit= "+"+str(round(float(percentage)*-1,2))+"%", legend= "Prediction Chart" , max=5000, labels=line_labels, values=line_values)    

@app.route("/ANTM", methods=["POST", "GET"])
def predictAntm():
    if request.method == "GET":
        return render_template("antm.html")
    
    else:
        modelAntm = load_model(r"C:\Users\LENOVO\python skripsi\static\models\ANTM.h5")
        inputan = []

        inputan.append(float(request.form["antm_3"]))
        inputan.append(float(request.form["antm_2"]))
        inputan.append(float(request.form["antm_1"]))

        predict = inputpredict(modelAntm,inputan)
        inputan.append(predict[2])
        if (inputan[2] == predict[2]):
            line_labels = labels
            line_values = inputan
            return render_template("antm.html",result= predict[2],profit= "+0.0%", legend= "Prediction Chart" , max=5000, labels=line_labels, values=line_values)
        if (inputan[2] > predict[2]):
            percentage = ((inputan[2]-predict[2])/predict[2])*100
            line_labels = labels
            line_values = inputan
            return render_template("antm.html",result= predict[2],profit= "-"+str(round(float(percentage),2))+"%", legend= "Prediction Chart" , max=5000, labels=line_labels, values=line_values)
        if (inputan[2] < predict[2]):
            percentage = ((inputan[2]-predict[2])/predict[2])*100
            line_labels = labels
            line_values = inputan
            return render_template("antm.html",result= predict[2],profit= "+"+str(round(float(percentage)*-1,2))+"%", legend= "Prediction Chart" , max=5000, labels=line_labels, values=line_values)

@app.route("/BBCA", methods=["POST", "GET"])
def predictBBCA():
    if request.method == "GET":
        return render_template("bbca.html")
    
    else:
        modelBbca = load_model(r"C:\Users\LENOVO\python skripsi\static\models\BBCA.h5")
        inputan = []

        inputan.append(float(request.form["bbca_3"]))
        inputan.append(float(request.form["bbca_2"]))
        inputan.append(float(request.form["bbca_1"]))

        predict = inputpredict(modelBbca,inputan)
        inputan.append(predict[2])
        if (inputan[2] == predict[2]):
            line_labels = labels
            line_values = inputan
            return render_template("bbca.html",result= predict[2],profit= "+0.0%", legend= "Prediction Chart" , max=10000, labels=line_labels, values=line_values)
        if (inputan[2] > predict[2]):
            percentage = ((inputan[2]-predict[2])/predict[2])*100
            line_labels = labels
            line_values = inputan
            return render_template("bbca.html",result= predict[2],profit= "-"+str(round(float(percentage),2))+"%", max=10000, labels=line_labels, values=line_values)
        if (inputan[2] < predict[2]):
            percentage = ((inputan[2]-predict[2])/predict[2])*100
            line_labels = labels
            line_values = inputan
            return render_template("bbca.html",result= predict[2],profit= "+"+str(round(float(percentage)*-1,2))+"%", max=10000, labels=line_labels, values=line_values)

@app.route("/BBNI", methods=["POST", "GET"])
def predictBBNI():
    if request.method == "GET":
        return render_template("bbni.html")
    
    else:
        modelBbni = load_model(r"C:\Users\LENOVO\python skripsi\static\models\BBNI.h5")
        inputan = []

        inputan.append(float(request.form["bbni_3"]))
        inputan.append(float(request.form["bbni_2"]))
        inputan.append(float(request.form["bbni_1"]))

        predict = inputpredict(modelBbni,inputan)
        inputan.append(predict[2])
        if (inputan[2] == predict[2]):
            line_labels = labels
            line_values = inputan
            return render_template("bbni.html",result= predict[2],profit= "+0.0%", max=10000, labels=line_labels, values=line_values)
        if (inputan[2] > predict[2]):
            line_labels = labels
            line_values = inputan
            percentage = ((inputan[2]-predict[2])/predict[2])*100
            return render_template("bbni.html",result= predict[2],profit= "-"+str(round(float(percentage),2))+"%", max=10000, labels=line_labels, values=line_values)
        if (inputan[2] < predict[2]):
            percentage = ((inputan[2]-predict[2])/predict[2])*100
            line_labels = labels
            line_values = inputan
            return render_template("bbni.html",result= predict[2],profit= "+"+str(round(float(percentage)*-1,2))+"%", max=10000, labels=line_labels, values=line_values)

@app.route("/BBRI", methods=["POST", "GET"])
def predictBBRI():
    if request.method == "GET":
        return render_template("bbri.html")
    
    else:
        modelBbri = load_model(r"C:\Users\LENOVO\python skripsi\static\models\BBRI.h5")
        inputan = []

        inputan.append(float(request.form["bbri_3"]))
        inputan.append(float(request.form["bbri_2"]))
        inputan.append(float(request.form["bbri_1"]))

        predict = inputpredict(modelBbri,inputan)
        inputan.append(predict[2])
        if (inputan[2] == predict[2]):
            line_labels = labels
            line_values = inputan
            return render_template("bbri.html",result= predict[2],profit= "+0.0%", max=10000, labels=line_labels, values=line_values)
        if (inputan[2] > predict[2]):
            line_labels = labels
            line_values = inputan
            percentage = ((inputan[2]-predict[2])/predict[2])*100
            return render_template("bbri.html",result= predict[2],profit= "-"+str(round(float(percentage),2))+"%", max=10000, labels=line_labels, values=line_values)
        if (inputan[2] < predict[2]):
            line_labels = labels
            line_values = inputan
            percentage = ((inputan[2]-predict[2])/predict[2])*100
            return render_template("bbri.html",result= predict[2],profit= "+"+str(round(float(percentage)*-1,2))+"%", max=10000, labels=line_labels, values=line_values)

@app.route("/BBTN", methods=["POST", "GET"])
def predictBBTN():
    if request.method == "GET":
        return render_template("bbtn.html")
    
    else:
        modelBbtn = load_model(r"C:\Users\LENOVO\python skripsi\static\models\BBTN.h5")
        inputan = []

        inputan.append(float(request.form["bbtn_3"]))
        inputan.append(float(request.form["bbtn_2"]))
        inputan.append(float(request.form["bbtn_1"]))

        predict = inputpredict(modelBbtn,inputan)
        inputan.append(predict[2])
        if (inputan[2] == predict[2]):
            line_labels = labels
            line_values = inputan
            return render_template("bbtn.html",result= predict[2],profit= "+0.0%", max=5000, labels=line_labels, values=line_values)
        if (inputan[2] > predict[2]):
            percentage = ((inputan[2]-predict[2])/predict[2])*100
            line_labels = labels
            line_values = inputan
            return render_template("bbtn.html",result= predict[2],profit= "-"+str(round(float(percentage),2))+"%", max=5000, labels=line_labels, values=line_values)
        if (inputan[2] < predict[2]):
            percentage = ((inputan[2]-predict[2])/predict[2])*100
            line_labels = labels
            line_values = inputan
            return render_template("bbtn.html",result= predict[2],profit= "+"+str(round(float(percentage)*-1,2))+"%", max=5000, labels=line_labels, values=line_values)

@app.route("/BMRI", methods=["POST", "GET"])
def predictBMRI():
    if request.method == "GET":
        return render_template("bmri.html")
    
    else:
        modelBmri = load_model(r"C:\Users\LENOVO\python skripsi\static\models\BMRI.h5")
        inputan = []

        inputan.append(float(request.form["bmri_3"]))
        inputan.append(float(request.form["bmri_2"]))
        inputan.append(float(request.form["bmri_1"]))

        predict = inputpredict(modelBmri,inputan)
        inputan.append(predict[2])
        if (inputan[2] == predict[2]):
            line_labels = labels
            line_values = inputan
            return render_template("bmri.html",result= predict[2],profit= "+0.0%", max=10000, labels=line_labels, values=line_values)
        if (inputan[2] > predict[2]):
            percentage = ((inputan[2]-predict[2])/predict[2])*100
            line_labels = labels
            line_values = inputan
            return render_template("bmri.html",result= predict[2],profit= "-"+str(round(float(percentage),2))+"%", max=10000, labels=line_labels, values=line_values)
        if (inputan[2] < predict[2]):
            percentage = ((inputan[2]-predict[2])/predict[2])*100
            line_labels = labels
            line_values = inputan
            return render_template("bmri.html",result= predict[2],profit= "+"+str(round(float(percentage)*-1,2))+"%", max=10000, labels=line_labels, values=line_values)

@app.route("/EXCL", methods=["POST", "GET"])
def predictExcl():
    if request.method == "GET":
        return render_template("excl.html")
    
    else:
        modelExcl = load_model(r"C:\Users\LENOVO\python skripsi\static\models\EXCL.h5")
        inputan = []

        inputan.append(float(request.form["excl_3"]))
        inputan.append(float(request.form["excl_2"]))
        inputan.append(float(request.form["excl_1"]))

        predict = inputpredict(modelExcl,inputan)
        inputan.append(predict[2])
        if (inputan[2] == predict[2]):
            line_labels = labels
            line_values = inputan
            return render_template("excl.html",result= predict[2],profit= "+0.0%", max=5000, labels=line_labels, values=line_values)
        if (inputan[2] > predict[2]):
            percentage = ((inputan[2]-predict[2])/predict[2])*100
            line_labels = labels
            line_values = inputan
            return render_template("excl.html",result= predict[2],profit= "-"+str(round(float(percentage),2))+"%", max=5000, labels=line_labels, values=line_values)
        if (inputan[2] < predict[2]):
            percentage = ((inputan[2]-predict[2])/predict[2])*100
            line_labels = labels
            line_values = inputan
            return render_template("excl.html",result= predict[2],profit= "+"+str(round(float(percentage)*-1,2))+"%", max=5000, labels=line_labels, values=line_values)

@app.route("/GGRM", methods=["POST", "GET"])
def predictGGRM():
    if request.method == "GET":
        return render_template("ggrm.html")
    
    else:
        modelGgrm = load_model(r"C:\Users\LENOVO\python skripsi\static\models\GGRM.h5")
        inputan = []

        inputan.append(float(request.form["ggrm_3"]))
        inputan.append(float(request.form["ggrm_2"]))
        inputan.append(float(request.form["ggrm_1"]))

        predict = inputpredict(modelGgrm,inputan)
        inputan.append(predict[2])
        if (inputan[2] == predict[2]):
            line_labels = labels
            line_values = inputan
            return render_template("ggrm.html",result= predict[2],profit= "+0.0%", max=35000, labels=line_labels, values=line_values)
        if (inputan[2] > predict[2]):
            percentage = ((inputan[2]-predict[2])/predict[2])*100
            line_labels = labels
            line_values = inputan
            return render_template("ggrm.html",result= predict[2],profit= "-"+str(round(float(percentage),2))+"%", max=35000, labels=line_labels, values=line_values)
        if (inputan[2] < predict[2]):
            percentage = ((inputan[2]-predict[2])/predict[2])*100
            line_labels = labels
            line_values = inputan
            return render_template("ggrm.html",result= predict[2],profit= "+"+str(round(float(percentage)*-1,2))+"%", max=35000, labels=line_labels, values=line_values)

@app.route("/HMSP", methods=["POST", "GET"])
def predictHMSP():
    if request.method == "GET":
        return render_template("hmsp.html")
    
    else:
        modelHmsp = load_model(r"C:\Users\LENOVO\python skripsi\static\models\HMSP.h5")
        inputan = []

        inputan.append(float(request.form["hmsp_3"]))
        inputan.append(float(request.form["hmsp_2"]))
        inputan.append(float(request.form["hmsp_1"]))

        predict = inputpredict(modelHmsp,inputan)
        inputan.append(predict[2])
        if (inputan[2] == predict[2]):
            line_labels = labels
            line_values = inputan
            return render_template("hmsp.html",result= predict[2],profit= "+0.0%", max=5000, labels=line_labels, values=line_values)
        if (inputan[2] > predict[2]):
            percentage = ((inputan[2]-predict[2])/predict[2])*100
            line_labels = labels
            line_values = inputan
            return render_template("hmsp.html",result= predict[2],profit= "-"+str(round(float(percentage),2))+"%", max=5000, labels=line_labels, values=line_values)
        if (inputan[2] < predict[2]):
            percentage = ((inputan[2]-predict[2])/predict[2])*100
            line_labels = labels
            line_values = inputan
            return render_template("hmsp.html",result= predict[2],profit= "+"+str(round(float(percentage)*-1,2))+"%", max=5000, labels=line_labels, values=line_values)

@app.route("/ICBP", methods=["POST", "GET"])
def predictICBP():
    if request.method == "GET":
        return render_template("icbp.html")
    
    else:
        modelIcbp = load_model(r"C:\Users\LENOVO\python skripsi\static\models\ICBP.h5")
        inputan = []

        inputan.append(float(request.form["icbp_3"]))
        inputan.append(float(request.form["icbp_2"]))
        inputan.append(float(request.form["icbp_1"]))

        predict = inputpredict(modelIcbp,inputan)
        inputan.append(predict[2])
        if (inputan[2] == predict[2]):
            line_labels = labels
            line_values = inputan
            return render_template("icbp.html",result= predict[2],profit= "+0.0%", max=10000, labels=line_labels, values=line_values)
        if (inputan[2] > predict[2]):
            percentage = ((inputan[2]-predict[2])/predict[2])*100
            line_labels = labels
            line_values = inputan
            return render_template("icbp.html",result= predict[2],profit= "-"+str(round(float(percentage),2))+"%", max=10000, labels=line_labels, values=line_values)
        if (inputan[2] < predict[2]):
            percentage = ((inputan[2]-predict[2])/predict[2])*100
            line_labels = labels
            line_values = inputan
            return render_template("icbp.html",result= predict[2],profit= "+"+str(round(float(percentage)*-1,2))+"%", max=10000, labels=line_labels, values=line_values)

@app.route("/INDF", methods=["POST", "GET"])
def predictINDF():
    if request.method == "GET":
        return render_template("indf.html")
    
    else:
        modelIndf = load_model(r"C:\Users\LENOVO\python skripsi\static\models\INDF.h5")
        inputan = []

        inputan.append(float(request.form["indf_3"]))
        inputan.append(float(request.form["indf_2"]))
        inputan.append(float(request.form["indf_1"]))

        predict = inputpredict(modelIndf,inputan)
        inputan.append(predict[2])
        if (inputan[2] == predict[2]):
            line_labels = labels
            line_values = inputan
            return render_template("indf.html",result= predict[2],profit= "+0.0%", max=10000, labels=line_labels, values=line_values)
        if (inputan[2] > predict[2]):
            line_labels = labels
            line_values = inputan
            percentage = ((inputan[2]-predict[2])/predict[2])*100
            return render_template("indf.html",result= predict[2],profit= "-"+str(round(float(percentage),2))+"%", max=10000, labels=line_labels, values=line_values)
        if (inputan[2] < predict[2]):
            percentage = ((inputan[2]-predict[2])/predict[2])*100
            line_labels = labels
            line_values = inputan
            return render_template("indf.html",result= predict[2],profit= "+"+str(round(float(percentage)*-1,2))+"%", max=10000, labels=line_labels, values=line_values)

@app.route("/JPFA", methods=["POST", "GET"])
def predictJPFA():
    if request.method == "GET":
        return render_template("jpfa.html")
    
    else:
        modelJpfa = load_model(r"C:\Users\LENOVO\python skripsi\static\models\JPFA.h5")
        inputan = []

        inputan.append(float(request.form["jpfa_3"]))
        inputan.append(float(request.form["jpfa_2"]))
        inputan.append(float(request.form["jpfa_1"]))

        predict = inputpredict(modelJpfa,inputan)
        inputan.append(predict[2])
        if (inputan[2] == predict[2]):
            line_labels = labels
            line_values = inputan
            return render_template("jpfa.html",result= predict[2],profit= "+0.0%", max=5000, labels=line_labels, values=line_values)
        if (inputan[2] > predict[2]):
            percentage = ((inputan[2]-predict[2])/predict[2])*100
            line_labels = labels
            line_values = inputan
            return render_template("jpfa.html",result= predict[2],profit= "-"+str(round(float(percentage),2))+"%", max=5000, labels=line_labels, values=line_values)
        if (inputan[2] < predict[2]):
            percentage = ((inputan[2]-predict[2])/predict[2])*100
            line_labels = labels
            line_values = inputan
            return render_template("jpfa.html",result= predict[2],profit= "+"+str(round(float(percentage)*-1,2))+"%", max=5000, labels=line_labels, values=line_values)

@app.route("/MDKA", methods=["POST", "GET"])
def predictMdka():
    if request.method == "GET":
        return render_template("mdka.html")
    
    else:
        modelMdka = load_model(r"C:\Users\LENOVO\python skripsi\static\models\MDKA.h5")
        inputan = []

        inputan.append(float(request.form["mdka_3"]))
        inputan.append(float(request.form["mdka_2"]))
        inputan.append(float(request.form["mdka_1"]))

        predict = inputpredict(modelMdka,inputan)
        inputan.append(predict[2])
        if (inputan[2] == predict[2]):
            line_labels = labels
            line_values = inputan
            return render_template("mdka.html",result= predict[2],profit= "+0.0%", max=10000, labels=line_labels, values=line_values)
        if (inputan[2] > predict[2]):
            percentage = ((inputan[2]-predict[2])/predict[2])*100
            line_labels = labels
            line_values = inputan
            return render_template("mdka.html",result= predict[2],profit= "-"+str(round(float(percentage),2))+"%", max=10000, labels=line_labels, values=line_values)
        if (inputan[2] < predict[2]):
            percentage = ((inputan[2]-predict[2])/predict[2])*100
            line_labels = labels
            line_values = inputan
            return render_template("mdka.html",result= predict[2],profit= "+"+str(round(float(percentage)*-1,2))+"%", max=10000, labels=line_labels, values=line_values)

@app.route("/TLKM", methods=["POST", "GET"])
def predictTlkm():
    if request.method == "GET":
        return render_template("tlkm.html")
    
    else:
        modelTlkm = load_model(r"C:\Users\LENOVO\python skripsi\static\models\TLKM.h5")
        inputan = []

        inputan.append(float(request.form["tlkm_3"]))
        inputan.append(float(request.form["tlkm_2"]))
        inputan.append(float(request.form["tlkm_1"]))

        predict = inputpredict(modelTlkm,inputan)
        inputan.append(predict[2])
        if (inputan[2] == predict[2]):
            line_labels = labels
            line_values = inputan
            return render_template("tlkm.html",result= predict[2],profit= "+0.0%", max=5000, labels=line_labels, values=line_values)
        if (inputan[2] > predict[2]):
            percentage = ((inputan[2]-predict[2])/predict[2])*100
            line_labels = labels
            line_values = inputan
            return render_template("tlkm.html",result= predict[2],profit= "-"+str(round(float(percentage),2))+"%", max=5000, labels=line_labels, values=line_values)
        if (inputan[2] < predict[2]):
            percentage = ((inputan[2]-predict[2])/predict[2])*100
            line_labels = labels
            line_values = inputan
            return render_template("tlkm.html",result= predict[2],profit= "+"+str(round(float(percentage)*-1,2))+"%", max=5000, labels=line_labels, values=line_values)

if __name__ == "__main__":
    app.run(debug=True)